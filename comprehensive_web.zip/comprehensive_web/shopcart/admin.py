from django.contrib import admin
from shopcart import models
# Register your models here.

admin.site.register(models.OrdersModel)
admin.site.register(models.DetailModel)
